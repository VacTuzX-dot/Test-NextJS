
import Link from "next/link";

const Index = () => (
  <div>
    <h1>Home Page</h1>

    <style jsx global>{`
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
    `}</style>

    <style jsx>{`
      h1 {
        background: pink;
      }
    `}</style>

    <Link href="/blog">
      <a>Blog</a>
    </Link>
  </div>
);

export default Index;
